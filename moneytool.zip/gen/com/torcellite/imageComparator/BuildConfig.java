/** Automatically generated file. DO NOT MODIFY */
package com.torcellite.imageComparator;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}